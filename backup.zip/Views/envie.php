<br><br><br>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-8">
      <div class="card mb-4">
        <div class="card-body">
          <hr>
          <div class="alert alert-danger" role="alert">
            Usuario y/o Contraseña incorrecta.
          </div>
          <form action="" autocomplete="off" method="post">
              <div class="form-group">
                <label for="exampleInputEmail1"> <strong>Título</strong>
                  <span style="color: red;font-weight: bold;">   * </span></label>
                <input type="text" class="form-control" placeholder="Título do post" name="titulo" maxlenght="80"> 
              </div>

              <div class="form-group">
                <label for="exampleFormControlFile1">
                  <strong>Imagem</strong>
                  
                </label>
                <input type="file" class="form-control-file" name="imagem">
              </div>

              <div class="form-group">
                <label for="exampleInputPassword1">
                  <strong>Endereço do post</strong>
                  <span style="color: red;font-weight: bold;"> *  </span> 
                </label>
                <input type="text" class="form-control"  placeholder="Endereço do Post contendo http://"  name="link">
              </div>
              
              <div class="form-group">
                <label for="exampleFormControlSelect1">
                  <strong>Categoria</strong>
                  <span style="color: red;font-weight: bold;">  *  </span>
                </label>
               <select class="custom-select">
                  <option selected>Open this select menu</option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                </select>
              </div>

              <div class="form-group">
                <label for="exampleFormControlTextarea1">
                  <strong>Descrição</strong>
                  <span style="color: red;font-weight: bold;"> *   </span></label>
                <textarea class="form-control" name="texto" maxlenght="2000"></textarea>
              </div>
              
              <button type="submit" class="btn btn-primary btn-block" name="salva">Enviar link</button>
            </form>   
          </div>
        </div>
      </div>

     
      <div class="col-md-4">

       
        <div class="card my-4">
         
          <div class="card-body">
           <iframe data-aa="1574678" src="//ad.a-ads.com/1574678?size=300x250" scrolling="no" style="width:300px; height:250px; border:0px; padding:0; overflow:hidden" allowtransparency="true"></iframe>
          </div>
        </div>

        <div class="card my-4">
          
          <div class="card-body">
            <h5>Categories</h5>
            <div class="row">
              <div class="col-lg-6">
                <ul class="list-unstyled mb-0">
                  <li>
                    <a href="<?= BASE_URL; ?>">Web Design</a>
                  </li>
                  <li>
                    <a href="#">HTML</a>
                  </li>
                  <li>
                    <a href="#">Freebies</a>
                  </li>
                </ul>
              </div>
              <div class="col-lg-6">
                <ul class="list-unstyled mb-0">
                  <li>
                    <a href="#">JavaScript</a>
                  </li>
                  <li>
                    <a href="#">CSS</a>
                  </li>
                  <li>
                    <a href="#">Tutorials</a>
                  </li>
                </ul>
              </div>

            </div>
          </div>
      </div>
    </div>
  </div>
</div>
<section class="pt-5 pb-5">
    <div class="container">
         <div class="col-6">
            <h3 class="mb-3 text-primary">Links em Destaques:  </h3>
        </div>
        <hr>
        <div class="row mb-md-2">
            <?php foreach ($fixed as $post) { ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card shadow-sm  mb-4">
                        <div  class="position-relative">
                            <?php if(!empty($post['image'])){ ?>
                            <a href="<?= BASE_URL; ?>/post/go/<?= $post['slugUrl'];?>">
                                <img src="<?= BASE_URL; ?>/storage/images/<?= $post['image'];?>" class="card-img-top" alt="image" width="350" height="250">
                                     
                            <?php }else{ ?>
                                <img src="<?= BASE_URL; ?>/assets/images/no-img.gif" class="card-img-top" alt="image" width="350" height="250">
                            <?php } ?>
                            </a>
                            <div class="category"><?= $post['category'];?></div>
                        </div>
                          <div class="card-body">
                            <a href="<?= BASE_URL;?>/post/go/<?= $post['slugUrl'];?>">
                                <p class="font-weight-normal text-dark"><?= $post['titulo'];?></p>
                            </a>
                           
                            <div class="row">
                                <div class="col-md-6 d-flex">
                                   <button class="btn btn-sm btn-dark">Cliques: <?= $post['visitas'];?></button>
                                </div>
                                <div class="col-md-4 d-flex ">
                                    <a class=" border-0 ml-1" href="">
                                       <img src="<?= url("/assets/images/twitter.png");?>" width="25" >
                                    </a>
                                    <a class=" border-0 ml-1" href="">
                                        <img src="<?= url('/assets/images/whatsapp.png');?>" width="25" >
                                    </a>
                                    <a class=" border-0 ml-1" href="">
                                        <img src="<?= url('/assets/images/facebook.png');?>" width="25">
                                    </a>
                                    <a class=" border-dark ml-1" href="https://api.whatspapp.com/send?text=">
                                        <img src="<?= url('/assets/images/link.png');?>" width="25">
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
        <div class="row justify-content-center py-2">
            <!-- 728x90 -->
           <iframe width=728 height=90 src='https://anuncieaqui.top/ads.php?ref=2&anun=5&tamanho=728x90' scrolling=no frameborder=0 marginwidth=0 marginheight=0 name=AnuncieAqui></iframe>
        </div><br>
        <div class="row">
            <?php foreach ($listagem as $post) { ?>
            <div class="col-md-6 col-lg-4">
                <div class="card shadow-sm  mb-4">
                    <div  class="position-relative">
                        <?php if(!empty($post['image'])){ ?>
                        <a href="<?= BASE_URL; ?>/post/go/<?= $post['slugUrl'];?>">
                            <img src="<?= BASE_URL; ?>/storage/images/<?= $post['image'];?>" class="card-img-top" alt="image" width="350" height="250">
                                 
                        <?php }else{ ?>
                            <img src="<?= BASE_URL; ?>/assets/images/no-img.gif" class="card-img-top" alt="image" width="350" height="250">
                        <?php } ?>
                        </a>
                        <div class="category"><?= $post['category'];?></div>
                    </div>
                      <div class="card-body">
                        <a href="<?= BASE_URL;?>/post/go/<?= $post['slugUrl'];?>">
                            <p class="font-weight-normal text-dark"><?= $post['titulo'];?></p>
                        </a>
                       
                        <div class="row">
                            <div class="col-md-6 d-flex">
                               <button class="btn btn-sm btn-dark">Cliques: <?= $post['visitas'];?></button>
                            </div>
                            <div class="col-md-4 d-flex ">
                                <a class=" border-0 ml-1" href="">
                                   <img src="<?= url("/assets/images/twitter.png");?>" width="25" >
                                </a>
                                <a class=" border-0 ml-1" href="">
                                    <img src="<?= url('/assets/images/whatsapp.png');?>" width="25" >
                                </a>
                                <a class=" border-0 ml-1" href="">
                                    <img src="<?= url('/assets/images/facebook.png');?>" width="25">
                                </a>
                                <a class=" border-dark ml-1" href="https://api.whatspapp.com/send?text=">
                                    <img src="<?= url('/assets/images/link.png');?>" width="25">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?>
        </div> 
       
        <div class="row py-4 mt-md-5">
            <div class="col text-center">
               <ul class="pagination justify-content-center mb-4">

                <?php if($total > $maximo){ ?> 
                    <?php if ($pagina != 1) { ?>
                         <li class="page-item">
                            <a class="page-link" href="?pagina=1">&larr; Primeira</a>
                        </li>
                    <?php }else{ ?>
                        <li class="page-item disabled">
                            <a class="page-link" href="?pagina=1">&larr; Primeira</a>
                        </li>
                    <?php } ?>

                    <?php if ($previous != 0) { ?>
                        <li class="page-item">
                            <a class="page-link" href="?pagina=<?= $previous; ?>">&laquo;</a>
                        </li>
                    <?php }else{ ?>
                        <li class="page-item disabled">
                            <a class="page-link" href="#">&laquo; </a>
                        </li>
                    <?php } ?>

                    <?php for($i = $pagina - $range; $i <= $pagina - 1; $i++){ ?>
                        <?php if ($i >= 1) { ?>
                            <li class="page-item">
                                <a class="page-link" href="?pagina=<?= $i; ?>"><?= $i; ?> </a>
                            </li>
                        <?php } ?>
                    <?php } ?>
                <?php } ?> 

                    <li class="page-item active">
                        <a class="page-link disabled" href="?pagina=<?= $pagina; ?>"><?= $pagina; ?> 
                            <span class="sr-only">(current)</span>
                        </a>
                    </li>

                    <?php for ($i = $pagina + 1; $i <= $pagina + $range; $i++) { ?>
                        <?php if ($i <= $total_paginas) { ?>
                           <li class="page-item">
                                <a class="page-link" href="?pagina=<?= $i; ?>"><?= $i; ?> </a>
                            </li>
                        <?php } ?>
                     <?php } ?>

                    <?php if($next <= $total_paginas){ ?>
                        <li class="page-item ">
                            <a class="page-link" href="?pagina=<?= $next; ?>">&raquo; </a>
                        </li>
                    <?php }else{ ?>
                        <li class="page-item disabled">
                            <a class="page-link" href="?pagina=<?= $next; ?>">&raquo; </a>
                        </li>
                    <?php } ?>
                
                    <?php if($pagina != $total_paginas){ ?>
                        <li class="page-item ">
                            <a class="page-link" href="?pagina=<?= $total_paginas; ?>">Última &rarr; </a>
                        </li>
                    <?php }else{ ?>
                       <li class="page-item disabled">
                            <a class="page-link" href="?pagina=<?= $total_paginas; ?>">Última &rarr; </a>
                        </li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </div>
</section>
<br><br><br>