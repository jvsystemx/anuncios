<!DOCTYPE html>
<html lang="en">
<head>
  <!-- META SEO-->
  <meta charset="utf-8">
  
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="author" content="<?= TWITTER_USER; ?>">
  <meta name="description" content="<?= SITE_NAME_DESC; ?>" />
  <meta name="keywords" content="MegaLink, Agregador de links, Agregador de conteudos, divulgar blog, divulgar site, humor, celebridades, curiosidades, Automoveis, culinaria, esporte, jogos, moda, beleza, mulheres, saude,tecnologia" />
  <meta http-equiv="content-language" content="pt-br" />
  <meta name="dc.language" content="pt_BR" />
  <meta name="fb:app_id" content="<?= SITE_NAME; ?>" />
  <meta name="twitter:site" content="<?= TWITTER_USER; ?>" />
  <meta name="google-site-verification" content="tiOnvrkMFUhAdtdZYlRs3b7ntQaHdgUQkfICkEDNzuY" />
  <meta name="og:site_name" content="<?= SITE_NAME; ?>" />
  <meta property="og:locale" content="pt_BR" />
  <meta property="og:title" content="<?= SITE_NAME; ?>" />
  <meta property="og:description" content="<?= SITE_NAME_DESC; ?>" />
  <meta property="og:image" content="https://geralinks.com.br/images/facebook-thumb.jpg" />
  <meta property="og:image:type" content="image/jpg" />
  <meta property="og:image:width" content="200" />
  <meta property="og:image:height" content="200" />
  <meta name="robots" content="index, follow" />
  <meta name="Googlebot" content="index, follow" />
  <meta name="rating" content="general" />

  <title><?= SITE_NAME; ?></title>

  <link rel="stylesheet" href="<?= url("/assets/css/bootstrap.css"); ?>">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="<?= url("/assets/css/style.css"); ?>">
  <link rel="shortcut icon" type="image/x-icon" href="<?= url('/favicon.ico');?>" />

</head>
<body>

  
<nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
    <a class="navbar-brand" href="<?= url(); ?>">
      <img src="<?= url('/assets/images/banner.png'); ?>"  class="logo-image">
    </a>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="<?= url(); ?>">Home 
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link " href="<?= url("/envie"); ?>">Envie seu link</a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="<?= url("/sobre"); ?>">Sobre</a>
          </li>
          <li class="nav-item">
            <a class="nav-link " href="<?= url("/contato"); ?>">Contato</a>
          </li>
           
        </ul>
        <form class="form-search form-inline my-2 my-lg-0">
            <div class="form-group has-search">
              <i class="fas fa-search form-control-feedback"></i>
              <input type="text" class="form-control" placeholder="Procurar por ..." name="busca">
            </div>
        </form>
    </div>
</nav>
<br><br>
<div class="row justify-content-center py-2">
    <!-- 728x90 -->
   <iframe width=728 height=90 src='https://anuncieaqui.top/ads.php?ref=2&anun=5&tamanho=728x90' scrolling=no frameborder=0 marginwidth=0 marginheight=0 name=AnuncieAqui></iframe>
</div><br>

<!-- HOME -->
<?php $this->loadViewInTemplate($viewName, $viewData); ?>


  <!-- Footer-->
<div class="py-5 bg-light">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 mb-4 mb-lg-0">
        <img src="<?= url('/assets/images/banner.png'); ?>" width="250" height="90">
        <p class="text-muted">Laborum aute enim consectetur eu laboris commodo.</p>
        <ul class="contact-info list-unstyled">
          <li><a href="mailto:sales@landy.com" class="text-dark">teste@hotmail.com</a></li>
          <li><a href="tel:123456789" class="text-dark">+55 (00) 123 456 789</a></li>
        </ul>
        
      </div>
      <div class="col-lg-4 col-md-6 mt-5">
        <h5>Links rápidos</h5>
        <ul class="links list-unstyled">
          <li> <a href="#" class="text-muted">Home</a></li>
          <li> <a href="#" class="text-muted">Envie seu link</a></li>
          <li> <a href="#" class="text-muted">Contato</a></li>
           <li> <a href="#" class="text-muted">Contato</a></li>
          <li> <a href="#" class="text-muted">Privacidade</a></li>
        </ul>
      </div>
      <div class="col-lg-4 col-md-6 mt-5">
        <h5>Categorias</h5>
        <ul class="links list-unstyled">
          <li> <a href="#" class="text-muted">Minim labore nulla</a></li>
          <li> <a href="#" class="text-muted">Nulla qui nisi</a></li>
          <li> <a href="#" class="text-muted">Iris Vor Arnim</a></li>
          <li> <a href="#" class="text-muted">Consectetur cupidatat</a></li>
          <li> <a href="#" class="text-muted">Consectetur cupidatat</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>
<div class="py-3 bg-dark text-white">
  <div class="container">
    <div class="row">
      <div class="col-md-7 text-center text-md-left">
        <p class="mb-md-0">&copy; <?=  Date("Y"); ?> Your company. All rights reserved. </p>
      </div>
      <div class="col-md-5 text-center text-md-right">
        <p class="mb-0">Desenvolvido por <a href="" class="external text-white">Bootstrapious</a> </p>
      </div>
    </div>
  </div>
</div>

<div class="alert text-center cookiealert" role="alert">
   <b>Utilizamos cookies para garantir que você tenha a melhor experiência em nosso site. Ao continuar você confirma que aceita os termos e está ciente. Para mais informações, acesse: </b> 
     <a href="https://cookiesandyou.com/" target="_blank">Saber mais</a>
    <button type="button" class="btn btn-success btn-sm acceptcookies"> Eu concordo </button>
</div>


<script src="<?= url('/assets/js/jquery-3.3.1.slim.min.js'); ?>"></script>
<script src="<?= url('/assets/js/bootstrap.min.js'); ?>"></script>
<script src="<?= url('/assets/js/cookie.js'); ?>"></script>

</body>
</html>