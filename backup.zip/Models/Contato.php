<?php 

namespace Models;

use \Core\Models;


/**
 * 
 */
class ClassName extends Models
{
	
	public function __construct(argument)
	{
		# code...
	}
}