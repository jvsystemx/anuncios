<?php

//define("ENVIRONMENT", "development");
define("ENVIRONMENT", "production");

define("SITE_NAME", "MegaLinks | Agregador de link ");

define("SITE_NAME_DESC", "Agregador de Links e maior Portal de Blogs do Brasil. Navegue em conteÃºdo de Curiosidades, Humor, Esporte, Celebridades... Divulgue seu blog site grátis");

define("TWITTER_USER", "@carlos0ff");